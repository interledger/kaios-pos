/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./node_modules/.pnpm/preact@10.27.1/node_modules/preact/dist/preact.module.js
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var n,
  preact_module_l,
  preact_module_u,
  t,
  i,
  preact_module_r,
  preact_module_o,
  preact_module_e,
  preact_module_f,
  c,
  s,
  a,
  h,
  p = {},
  v = [],
  y = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
  w = Array.isArray;
function d(n, l) {
  for (var u in l) n[u] = l[u];
  return n;
}
function g(n) {
  n && n.parentNode && n.parentNode.removeChild(n);
}
function _(l, u, t) {
  var i,
    r,
    o,
    e = {};
  for (o in u) "key" == o ? i = u[o] : "ref" == o ? r = u[o] : e[o] = u[o];
  if (arguments.length > 2 && (e.children = arguments.length > 3 ? n.call(arguments, 2) : t), "function" == typeof l && null != l.defaultProps) for (o in l.defaultProps) void 0 === e[o] && (e[o] = l.defaultProps[o]);
  return m(l, e, i, r, null);
}
function m(n, t, i, r, o) {
  var e = {
    type: n,
    props: t,
    key: i,
    ref: r,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: null == o ? ++preact_module_u : o,
    __i: -1,
    __u: 0
  };
  return null == o && null != preact_module_l.vnode && preact_module_l.vnode(e), e;
}
function b() {
  return {
    current: null
  };
}
function k(n) {
  return n.children;
}
function x(n, l) {
  this.props = n, this.context = l;
}
function S(n, l) {
  if (null == l) return n.__ ? S(n.__, n.__i + 1) : null;
  for (var u; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
  return "function" == typeof n.type ? S(n) : null;
}
function C(n) {
  var l, u;
  if (null != (n = n.__) && null != n.__c) {
    for (n.__e = n.__c.base = null, l = 0; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) {
      n.__e = n.__c.base = u.__e;
      break;
    }
    return C(n);
  }
}
function M(n) {
  (!n.__d && (n.__d = !0) && i.push(n) && !$.__r++ || preact_module_r != preact_module_l.debounceRendering) && ((preact_module_r = preact_module_l.debounceRendering) || preact_module_o)($);
}
function $() {
  for (var n, u, t, r, o, f, c, s = 1; i.length;) i.length > s && i.sort(preact_module_e), n = i.shift(), s = i.length, n.__d && (t = void 0, o = (r = (u = n).__v).__e, f = [], c = [], u.__P && ((t = d({}, r)).__v = r.__v + 1, preact_module_l.vnode && preact_module_l.vnode(t), O(u.__P, t, r, u.__n, u.__P.namespaceURI, 32 & r.__u ? [o] : null, f, null == o ? S(r) : o, !!(32 & r.__u), c), t.__v = r.__v, t.__.__k[t.__i] = t, N(f, t, c), t.__e != o && C(t)));
  $.__r = 0;
}
function I(n, l, u, t, i, r, o, e, f, c, s) {
  var a,
    h,
    y,
    w,
    d,
    g,
    _,
    m = t && t.__k || v,
    b = l.length;
  for (f = P(u, l, m, f, b), a = 0; a < b; a++) null != (y = u.__k[a]) && (h = -1 == y.__i ? p : m[y.__i] || p, y.__i = a, g = O(n, y, h, i, r, o, e, f, c, s), w = y.__e, y.ref && h.ref != y.ref && (h.ref && B(h.ref, null, y), s.push(y.ref, y.__c || w, y)), null == d && null != w && (d = w), (_ = !!(4 & y.__u)) || h.__k === y.__k ? f = A(y, f, n, _) : "function" == typeof y.type && void 0 !== g ? f = g : w && (f = w.nextSibling), y.__u &= -7);
  return u.__e = d, f;
}
function P(n, l, u, t, i) {
  var r,
    o,
    e,
    f,
    c,
    s = u.length,
    a = s,
    h = 0;
  for (n.__k = new Array(i), r = 0; r < i; r++) null != (o = l[r]) && "boolean" != typeof o && "function" != typeof o ? (f = r + h, (o = n.__k[r] = "string" == typeof o || "number" == typeof o || "bigint" == typeof o || o.constructor == String ? m(null, o, null, null, null) : w(o) ? m(k, {
    children: o
  }, null, null, null) : null == o.constructor && o.__b > 0 ? m(o.type, o.props, o.key, o.ref ? o.ref : null, o.__v) : o).__ = n, o.__b = n.__b + 1, e = null, -1 != (c = o.__i = L(o, u, f, a)) && (a--, (e = u[c]) && (e.__u |= 2)), null == e || null == e.__v ? (-1 == c && (i > s ? h-- : i < s && h++), "function" != typeof o.type && (o.__u |= 4)) : c != f && (c == f - 1 ? h-- : c == f + 1 ? h++ : (c > f ? h-- : h++, o.__u |= 4))) : n.__k[r] = null;
  if (a) for (r = 0; r < s; r++) null != (e = u[r]) && 0 == (2 & e.__u) && (e.__e == t && (t = S(e)), D(e, e));
  return t;
}
function A(n, l, u, t) {
  var i, r;
  if ("function" == typeof n.type) {
    for (i = n.__k, r = 0; i && r < i.length; r++) i[r] && (i[r].__ = n, l = A(i[r], l, u, t));
    return l;
  }
  n.__e != l && (t && (l && n.type && !l.parentNode && (l = S(n)), u.insertBefore(n.__e, l || null)), l = n.__e);
  do {
    l = l && l.nextSibling;
  } while (null != l && 8 == l.nodeType);
  return l;
}
function H(n, l) {
  return l = l || [], null == n || "boolean" == typeof n || (w(n) ? n.some(function (n) {
    H(n, l);
  }) : l.push(n)), l;
}
function L(n, l, u, t) {
  var i,
    r,
    o,
    e = n.key,
    f = n.type,
    c = l[u],
    s = null != c && 0 == (2 & c.__u);
  if (null === c && null == n.key || s && e == c.key && f == c.type) return u;
  if (t > (s ? 1 : 0)) for (i = u - 1, r = u + 1; i >= 0 || r < l.length;) if (null != (c = l[o = i >= 0 ? i-- : r++]) && 0 == (2 & c.__u) && e == c.key && f == c.type) return o;
  return -1;
}
function T(n, l, u) {
  "-" == l[0] ? n.setProperty(l, null == u ? "" : u) : n[l] = null == u ? "" : "number" != typeof u || y.test(l) ? u : u + "px";
}
function j(n, l, u, t, i) {
  var r, o;
  n: if ("style" == l) {
    if ("string" == typeof u) n.style.cssText = u;else {
      if ("string" == typeof t && (n.style.cssText = t = ""), t) for (l in t) u && l in u || T(n.style, l, "");
      if (u) for (l in u) t && u[l] == t[l] || T(n.style, l, u[l]);
    }
  } else if ("o" == l[0] && "n" == l[1]) r = l != (l = l.replace(preact_module_f, "$1")), o = l.toLowerCase(), l = o in n || "onFocusOut" == l || "onFocusIn" == l ? o.slice(2) : l.slice(2), n.l || (n.l = {}), n.l[l + r] = u, u ? t ? u.u = t.u : (u.u = c, n.addEventListener(l, r ? a : s, r)) : n.removeEventListener(l, r ? a : s, r);else {
    if ("http://www.w3.org/2000/svg" == i) l = l.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");else if ("width" != l && "height" != l && "href" != l && "list" != l && "form" != l && "tabIndex" != l && "download" != l && "rowSpan" != l && "colSpan" != l && "role" != l && "popover" != l && l in n) try {
      n[l] = null == u ? "" : u;
      break n;
    } catch (n) {}
    "function" == typeof u || (null == u || !1 === u && "-" != l[4] ? n.removeAttribute(l) : n.setAttribute(l, "popover" == l && 1 == u ? "" : u));
  }
}
function F(n) {
  return function (u) {
    if (this.l) {
      var t = this.l[u.type + n];
      if (null == u.t) u.t = c++;else if (u.t < t.u) return;
      return t(preact_module_l.event ? preact_module_l.event(u) : u);
    }
  };
}
function O(n, u, t, i, r, o, e, f, c, s) {
  var a,
    h,
    p,
    v,
    y,
    _,
    m,
    b,
    S,
    C,
    M,
    $,
    P,
    A,
    H,
    L,
    T,
    j = u.type;
  if (null != u.constructor) return null;
  128 & t.__u && (c = !!(32 & t.__u), o = [f = u.__e = t.__e]), (a = preact_module_l.__b) && a(u);
  n: if ("function" == typeof j) try {
    if (b = u.props, S = "prototype" in j && j.prototype.render, C = (a = j.contextType) && i[a.__c], M = a ? C ? C.props.value : a.__ : i, t.__c ? m = (h = u.__c = t.__c).__ = h.__E : (S ? u.__c = h = new j(b, M) : (u.__c = h = new x(b, M), h.constructor = j, h.render = E), C && C.sub(h), h.props = b, h.state || (h.state = {}), h.context = M, h.__n = i, p = h.__d = !0, h.__h = [], h._sb = []), S && null == h.__s && (h.__s = h.state), S && null != j.getDerivedStateFromProps && (h.__s == h.state && (h.__s = d({}, h.__s)), d(h.__s, j.getDerivedStateFromProps(b, h.__s))), v = h.props, y = h.state, h.__v = u, p) S && null == j.getDerivedStateFromProps && null != h.componentWillMount && h.componentWillMount(), S && null != h.componentDidMount && h.__h.push(h.componentDidMount);else {
      if (S && null == j.getDerivedStateFromProps && b !== v && null != h.componentWillReceiveProps && h.componentWillReceiveProps(b, M), !h.__e && null != h.shouldComponentUpdate && !1 === h.shouldComponentUpdate(b, h.__s, M) || u.__v == t.__v) {
        for (u.__v != t.__v && (h.props = b, h.state = h.__s, h.__d = !1), u.__e = t.__e, u.__k = t.__k, u.__k.some(function (n) {
          n && (n.__ = u);
        }), $ = 0; $ < h._sb.length; $++) h.__h.push(h._sb[$]);
        h._sb = [], h.__h.length && e.push(h);
        break n;
      }
      null != h.componentWillUpdate && h.componentWillUpdate(b, h.__s, M), S && null != h.componentDidUpdate && h.__h.push(function () {
        h.componentDidUpdate(v, y, _);
      });
    }
    if (h.context = M, h.props = b, h.__P = n, h.__e = !1, P = preact_module_l.__r, A = 0, S) {
      for (h.state = h.__s, h.__d = !1, P && P(u), a = h.render(h.props, h.state, h.context), H = 0; H < h._sb.length; H++) h.__h.push(h._sb[H]);
      h._sb = [];
    } else do {
      h.__d = !1, P && P(u), a = h.render(h.props, h.state, h.context), h.state = h.__s;
    } while (h.__d && ++A < 25);
    h.state = h.__s, null != h.getChildContext && (i = d(d({}, i), h.getChildContext())), S && !p && null != h.getSnapshotBeforeUpdate && (_ = h.getSnapshotBeforeUpdate(v, y)), L = a, null != a && a.type === k && null == a.key && (L = V(a.props.children)), f = I(n, w(L) ? L : [L], u, t, i, r, o, e, f, c, s), h.base = u.__e, u.__u &= -161, h.__h.length && e.push(h), m && (h.__E = h.__ = null);
  } catch (n) {
    if (u.__v = null, c || null != o) {
      if (n.then) {
        for (u.__u |= c ? 160 : 128; f && 8 == f.nodeType && f.nextSibling;) f = f.nextSibling;
        o[o.indexOf(f)] = null, u.__e = f;
      } else {
        for (T = o.length; T--;) g(o[T]);
        z(u);
      }
    } else u.__e = t.__e, u.__k = t.__k, n.then || z(u);
    preact_module_l.__e(n, u, t);
  } else null == o && u.__v == t.__v ? (u.__k = t.__k, u.__e = t.__e) : f = u.__e = q(t.__e, u, t, i, r, o, e, c, s);
  return (a = preact_module_l.diffed) && a(u), 128 & u.__u ? void 0 : f;
}
function z(n) {
  n && n.__c && (n.__c.__e = !0), n && n.__k && n.__k.forEach(z);
}
function N(n, u, t) {
  for (var i = 0; i < t.length; i++) B(t[i], t[++i], t[++i]);
  preact_module_l.__c && preact_module_l.__c(u, n), n.some(function (u) {
    try {
      n = u.__h, u.__h = [], n.some(function (n) {
        n.call(u);
      });
    } catch (n) {
      preact_module_l.__e(n, u.__v);
    }
  });
}
function V(n) {
  return "object" != _typeof(n) || null == n || n.__b && n.__b > 0 ? n : w(n) ? n.map(V) : d({}, n);
}
function q(u, t, i, r, o, e, f, c, s) {
  var a,
    h,
    v,
    y,
    d,
    _,
    m,
    b = i.props,
    k = t.props,
    x = t.type;
  if ("svg" == x ? o = "http://www.w3.org/2000/svg" : "math" == x ? o = "http://www.w3.org/1998/Math/MathML" : o || (o = "http://www.w3.org/1999/xhtml"), null != e) for (a = 0; a < e.length; a++) if ((d = e[a]) && "setAttribute" in d == !!x && (x ? d.localName == x : 3 == d.nodeType)) {
    u = d, e[a] = null;
    break;
  }
  if (null == u) {
    if (null == x) return document.createTextNode(k);
    u = document.createElementNS(o, x, k.is && k), c && (preact_module_l.__m && preact_module_l.__m(t, e), c = !1), e = null;
  }
  if (null == x) b === k || c && u.data == k || (u.data = k);else {
    if (e = e && n.call(u.childNodes), b = i.props || p, !c && null != e) for (b = {}, a = 0; a < u.attributes.length; a++) b[(d = u.attributes[a]).name] = d.value;
    for (a in b) if (d = b[a], "children" == a) ;else if ("dangerouslySetInnerHTML" == a) v = d;else if (!(a in k)) {
      if ("value" == a && "defaultValue" in k || "checked" == a && "defaultChecked" in k) continue;
      j(u, a, null, d, o);
    }
    for (a in k) d = k[a], "children" == a ? y = d : "dangerouslySetInnerHTML" == a ? h = d : "value" == a ? _ = d : "checked" == a ? m = d : c && "function" != typeof d || b[a] === d || j(u, a, d, b[a], o);
    if (h) c || v && (h.__html == v.__html || h.__html == u.innerHTML) || (u.innerHTML = h.__html), t.__k = [];else if (v && (u.innerHTML = ""), I("template" == t.type ? u.content : u, w(y) ? y : [y], t, i, r, "foreignObject" == x ? "http://www.w3.org/1999/xhtml" : o, e, f, e ? e[0] : i.__k && S(i, 0), c, s), null != e) for (a = e.length; a--;) g(e[a]);
    c || (a = "value", "progress" == x && null == _ ? u.removeAttribute("value") : null != _ && (_ !== u[a] || "progress" == x && !_ || "option" == x && _ != b[a]) && j(u, a, _, b[a], o), a = "checked", null != m && m != u[a] && j(u, a, m, b[a], o));
  }
  return u;
}
function B(n, u, t) {
  try {
    if ("function" == typeof n) {
      var i = "function" == typeof n.__u;
      i && n.__u(), i && null == u || (n.__u = n(u));
    } else n.current = u;
  } catch (n) {
    preact_module_l.__e(n, t);
  }
}
function D(n, u, t) {
  var i, r;
  if (preact_module_l.unmount && preact_module_l.unmount(n), (i = n.ref) && (i.current && i.current != n.__e || B(i, null, u)), null != (i = n.__c)) {
    if (i.componentWillUnmount) try {
      i.componentWillUnmount();
    } catch (n) {
      preact_module_l.__e(n, u);
    }
    i.base = i.__P = null;
  }
  if (i = n.__k) for (r = 0; r < i.length; r++) i[r] && D(i[r], u, t || "function" != typeof n.type);
  t || g(n.__e), n.__c = n.__ = n.__e = void 0;
}
function E(n, l, u) {
  return this.constructor(n, u);
}
function G(u, t, i) {
  var r, o, e, f;
  t == document && (t = document.documentElement), preact_module_l.__ && preact_module_l.__(u, t), o = (r = "function" == typeof i) ? null : i && i.__k || t.__k, e = [], f = [], O(t, u = (!r && i || t).__k = _(k, null, [u]), o || p, p, t.namespaceURI, !r && i ? [i] : o ? null : t.firstChild ? n.call(t.childNodes) : null, e, !r && i ? i : o ? o.__e : t.firstChild, r, f), N(e, u, f);
}
function J(n, l) {
  G(n, l, J);
}
function K(l, u, t) {
  var i,
    r,
    o,
    e,
    f = d({}, l.props);
  for (o in l.type && l.type.defaultProps && (e = l.type.defaultProps), u) "key" == o ? i = u[o] : "ref" == o ? r = u[o] : f[o] = void 0 === u[o] && null != e ? e[o] : u[o];
  return arguments.length > 2 && (f.children = arguments.length > 3 ? n.call(arguments, 2) : t), m(l.type, f, i || l.key, r || l.ref, null);
}
function Q(n) {
  function l(n) {
    var u, t;
    return this.getChildContext || (u = new Set(), (t = {})[l.__c] = this, this.getChildContext = function () {
      return t;
    }, this.componentWillUnmount = function () {
      u = null;
    }, this.shouldComponentUpdate = function (n) {
      this.props.value != n.value && u.forEach(function (n) {
        n.__e = !0, M(n);
      });
    }, this.sub = function (n) {
      u.add(n);
      var l = n.componentWillUnmount;
      n.componentWillUnmount = function () {
        u && u["delete"](n), l && l.call(n);
      };
    }), n.children;
  }
  return l.__c = "__cC" + h++, l.__ = n, l.Provider = l.__l = (l.Consumer = function (n, l) {
    return n.children(l);
  }).contextType = l, l;
}
n = v.slice, preact_module_l = {
  __e: function __e(n, l, u, t) {
    for (var i, r, o; l = l.__;) if ((i = l.__c) && !i.__) try {
      if ((r = i.constructor) && null != r.getDerivedStateFromError && (i.setState(r.getDerivedStateFromError(n)), o = i.__d), null != i.componentDidCatch && (i.componentDidCatch(n, t || {}), o = i.__d), o) return i.__E = i;
    } catch (l) {
      n = l;
    }
    throw n;
  }
}, preact_module_u = 0, t = function t(n) {
  return null != n && null == n.constructor;
}, x.prototype.setState = function (n, l) {
  var u;
  u = null != this.__s && this.__s != this.state ? this.__s : this.__s = d({}, this.state), "function" == typeof n && (n = n(d({}, u), this.props)), n && d(u, n), null != n && this.__v && (l && this._sb.push(l), M(this));
}, x.prototype.forceUpdate = function (n) {
  this.__v && (this.__e = !0, n && this.__h.push(n), M(this));
}, x.prototype.render = k, i = [], preact_module_o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, preact_module_e = function e(n, l) {
  return n.__v.__b - l.__v.__b;
}, $.__r = 0, preact_module_f = /(PointerCapture)$|Capture$/i, c = 0, s = F(!1), a = F(!0), h = 0;

;// ./node_modules/.pnpm/preact@10.27.1/node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
function jsxRuntime_module_typeof(o) { "@babel/helpers - typeof"; return jsxRuntime_module_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, jsxRuntime_module_typeof(o); }


var jsxRuntime_module_t = /["&<]/;
function jsxRuntime_module_n(r) {
  if (0 === r.length || !1 === jsxRuntime_module_t.test(r)) return r;
  for (var e = 0, n = 0, o = "", f = ""; n < r.length; n++) {
    switch (r.charCodeAt(n)) {
      case 34:
        f = "&quot;";
        break;
      case 38:
        f = "&amp;";
        break;
      case 60:
        f = "&lt;";
        break;
      default:
        continue;
    }
    n !== e && (o += r.slice(e, n)), o += f, e = n + 1;
  }
  return n !== e && (o += r.slice(e, n)), o;
}
var jsxRuntime_module_o = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
  jsxRuntime_module_f = 0,
  jsxRuntime_module_i = Array.isArray;
function jsxRuntime_module_u(e, t, n, o, i, u) {
  t || (t = {});
  var a,
    c,
    p = t;
  if ("ref" in p) for (c in p = {}, t) "ref" == c ? a = t[c] : p[c] = t[c];
  var l = {
    type: e,
    props: p,
    key: n,
    ref: a,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: --jsxRuntime_module_f,
    __i: -1,
    __u: 0,
    __source: i,
    __self: u
  };
  if ("function" == typeof e && (a = e.defaultProps)) for (c in a) void 0 === p[c] && (p[c] = a[c]);
  return preact_module_l.vnode && preact_module_l.vnode(l), l;
}
function jsxRuntime_module_a(r) {
  var t = jsxRuntime_module_u(e, {
    tpl: r,
    exprs: [].slice.call(arguments, 1)
  });
  return t.key = t.__v, t;
}
var jsxRuntime_module_c = {},
  jsxRuntime_module_p = /[A-Z]/g;
function l(e, t) {
  if (r.attr) {
    var f = r.attr(e, t);
    if ("string" == typeof f) return f;
  }
  if (t = function (r) {
    return null !== r && "object" == jsxRuntime_module_typeof(r) && "function" == typeof r.valueOf ? r.valueOf() : r;
  }(t), "ref" === e || "key" === e) return "";
  if ("style" === e && "object" == jsxRuntime_module_typeof(t)) {
    var i = "";
    for (var u in t) {
      var a = t[u];
      if (null != a && "" !== a) {
        var l = "-" == u[0] ? u : jsxRuntime_module_c[u] || (jsxRuntime_module_c[u] = u.replace(jsxRuntime_module_p, "-$&").toLowerCase()),
          s = ";";
        "number" != typeof a || l.startsWith("--") || jsxRuntime_module_o.test(l) || (s = "px;"), i = i + l + ":" + a + s;
      }
    }
    return e + '="' + jsxRuntime_module_n(i) + '"';
  }
  return null == t || !1 === t || "function" == typeof t || "object" == jsxRuntime_module_typeof(t) ? "" : !0 === t ? e : e + '="' + jsxRuntime_module_n("" + t) + '"';
}
function jsxRuntime_module_s(r) {
  if (null == r || "boolean" == typeof r || "function" == typeof r) return null;
  if ("object" == jsxRuntime_module_typeof(r)) {
    if (void 0 === r.constructor) return r;
    if (jsxRuntime_module_i(r)) {
      for (var e = 0; e < r.length; e++) r[e] = jsxRuntime_module_s(r[e]);
      return r;
    }
  }
  return jsxRuntime_module_n("" + r);
}

;// ./node_modules/.pnpm/preact@10.27.1/node_modules/preact/hooks/dist/hooks.module.js

var hooks_module_t,
  hooks_module_r,
  hooks_module_u,
  hooks_module_i,
  hooks_module_o = 0,
  hooks_module_f = [],
  hooks_module_c = preact_module_l,
  hooks_module_e = hooks_module_c.__b,
  hooks_module_a = hooks_module_c.__r,
  hooks_module_v = hooks_module_c.diffed,
  hooks_module_l = hooks_module_c.__c,
  hooks_module_m = hooks_module_c.unmount,
  hooks_module_s = hooks_module_c.__;
function hooks_module_p(n, t) {
  hooks_module_c.__h && hooks_module_c.__h(hooks_module_r, n, hooks_module_o || t), hooks_module_o = 0;
  var u = hooks_module_r.__H || (hooks_module_r.__H = {
    __: [],
    __h: []
  });
  return n >= u.__.length && u.__.push({}), u.__[n];
}
function hooks_module_d(n) {
  return hooks_module_o = 1, hooks_module_h(hooks_module_D, n);
}
function hooks_module_h(n, u, i) {
  var o = hooks_module_p(hooks_module_t++, 2);
  if (o.t = n, !o.__c && (o.__ = [i ? i(u) : hooks_module_D(void 0, u), function (n) {
    var t = o.__N ? o.__N[0] : o.__[0],
      r = o.t(t, n);
    t !== r && (o.__N = [r, o.__[1]], o.__c.setState({}));
  }], o.__c = hooks_module_r, !hooks_module_r.__f)) {
    var f = function f(n, t, r) {
      if (!o.__c.__H) return !0;
      var u = o.__c.__H.__.filter(function (n) {
        return !!n.__c;
      });
      if (u.every(function (n) {
        return !n.__N;
      })) return !c || c.call(this, n, t, r);
      var i = o.__c.props !== n;
      return u.forEach(function (n) {
        if (n.__N) {
          var t = n.__[0];
          n.__ = n.__N, n.__N = void 0, t !== n.__[0] && (i = !0);
        }
      }), c && c.call(this, n, t, r) || i;
    };
    hooks_module_r.__f = !0;
    var c = hooks_module_r.shouldComponentUpdate,
      e = hooks_module_r.componentWillUpdate;
    hooks_module_r.componentWillUpdate = function (n, t, r) {
      if (this.__e) {
        var u = c;
        c = void 0, f(n, t, r), c = u;
      }
      e && e.call(this, n, t, r);
    }, hooks_module_r.shouldComponentUpdate = f;
  }
  return o.__N || o.__;
}
function hooks_module_y(n, u) {
  var i = hooks_module_p(hooks_module_t++, 3);
  !hooks_module_c.__s && hooks_module_C(i.__H, u) && (i.__ = n, i.u = u, hooks_module_r.__H.__h.push(i));
}
function hooks_module_(n, u) {
  var i = hooks_module_p(hooks_module_t++, 4);
  !hooks_module_c.__s && hooks_module_C(i.__H, u) && (i.__ = n, i.u = u, hooks_module_r.__h.push(i));
}
function hooks_module_A(n) {
  return hooks_module_o = 5, hooks_module_T(function () {
    return {
      current: n
    };
  }, []);
}
function hooks_module_F(n, t, r) {
  hooks_module_o = 6, hooks_module_(function () {
    if ("function" == typeof n) {
      var r = n(t());
      return function () {
        n(null), r && "function" == typeof r && r();
      };
    }
    if (n) return n.current = t(), function () {
      return n.current = null;
    };
  }, null == r ? r : r.concat(n));
}
function hooks_module_T(n, r) {
  var u = hooks_module_p(hooks_module_t++, 7);
  return hooks_module_C(u.__H, r) && (u.__ = n(), u.__H = r, u.__h = n), u.__;
}
function hooks_module_q(n, t) {
  return hooks_module_o = 8, hooks_module_T(function () {
    return n;
  }, t);
}
function hooks_module_x(n) {
  var u = hooks_module_r.context[n.__c],
    i = hooks_module_p(hooks_module_t++, 9);
  return i.c = n, u ? (null == i.__ && (i.__ = !0, u.sub(hooks_module_r)), u.props.value) : n.__;
}
function hooks_module_P(n, t) {
  hooks_module_c.useDebugValue && hooks_module_c.useDebugValue(t ? t(n) : n);
}
function hooks_module_b(n) {
  var u = hooks_module_p(hooks_module_t++, 10),
    i = hooks_module_d();
  return u.__ = n, hooks_module_r.componentDidCatch || (hooks_module_r.componentDidCatch = function (n, t) {
    u.__ && u.__(n, t), i[1](n);
  }), [i[0], function () {
    i[1](void 0);
  }];
}
function hooks_module_g() {
  var n = hooks_module_p(hooks_module_t++, 11);
  if (!n.__) {
    for (var u = hooks_module_r.__v; null !== u && !u.__m && null !== u.__;) u = u.__;
    var i = u.__m || (u.__m = [0, 0]);
    n.__ = "P" + i[0] + "-" + i[1]++;
  }
  return n.__;
}
function hooks_module_j() {
  for (var n; n = hooks_module_f.shift();) if (n.__P && n.__H) try {
    n.__H.__h.forEach(hooks_module_z), n.__H.__h.forEach(hooks_module_B), n.__H.__h = [];
  } catch (t) {
    n.__H.__h = [], hooks_module_c.__e(t, n.__v);
  }
}
hooks_module_c.__b = function (n) {
  hooks_module_r = null, hooks_module_e && hooks_module_e(n);
}, hooks_module_c.__ = function (n, t) {
  n && t.__k && t.__k.__m && (n.__m = t.__k.__m), hooks_module_s && hooks_module_s(n, t);
}, hooks_module_c.__r = function (n) {
  hooks_module_a && hooks_module_a(n), hooks_module_t = 0;
  var i = (hooks_module_r = n.__c).__H;
  i && (hooks_module_u === hooks_module_r ? (i.__h = [], hooks_module_r.__h = [], i.__.forEach(function (n) {
    n.__N && (n.__ = n.__N), n.u = n.__N = void 0;
  })) : (i.__h.forEach(hooks_module_z), i.__h.forEach(hooks_module_B), i.__h = [], hooks_module_t = 0)), hooks_module_u = hooks_module_r;
}, hooks_module_c.diffed = function (n) {
  hooks_module_v && hooks_module_v(n);
  var t = n.__c;
  t && t.__H && (t.__H.__h.length && (1 !== hooks_module_f.push(t) && hooks_module_i === hooks_module_c.requestAnimationFrame || ((hooks_module_i = hooks_module_c.requestAnimationFrame) || hooks_module_w)(hooks_module_j)), t.__H.__.forEach(function (n) {
    n.u && (n.__H = n.u), n.u = void 0;
  })), hooks_module_u = hooks_module_r = null;
}, hooks_module_c.__c = function (n, t) {
  t.some(function (n) {
    try {
      n.__h.forEach(hooks_module_z), n.__h = n.__h.filter(function (n) {
        return !n.__ || hooks_module_B(n);
      });
    } catch (r) {
      t.some(function (n) {
        n.__h && (n.__h = []);
      }), t = [], hooks_module_c.__e(r, n.__v);
    }
  }), hooks_module_l && hooks_module_l(n, t);
}, hooks_module_c.unmount = function (n) {
  hooks_module_m && hooks_module_m(n);
  var t,
    r = n.__c;
  r && r.__H && (r.__H.__.forEach(function (n) {
    try {
      hooks_module_z(n);
    } catch (n) {
      t = n;
    }
  }), r.__H = void 0, t && hooks_module_c.__e(t, r.__v));
};
var hooks_module_k = "function" == typeof requestAnimationFrame;
function hooks_module_w(n) {
  var t,
    r = function r() {
      clearTimeout(u), hooks_module_k && cancelAnimationFrame(t), setTimeout(n);
    },
    u = setTimeout(r, 35);
  hooks_module_k && (t = requestAnimationFrame(r));
}
function hooks_module_z(n) {
  var t = hooks_module_r,
    u = n.__c;
  "function" == typeof u && (n.__c = void 0, u()), hooks_module_r = t;
}
function hooks_module_B(n) {
  var t = hooks_module_r;
  n.__c = n.__(), hooks_module_r = t;
}
function hooks_module_C(n, t) {
  return !n || n.length !== t.length || t.some(function (t, r) {
    return t !== n[r];
  });
}
function hooks_module_D(n, t) {
  return "function" == typeof t ? t(n) : t;
}

;// ./node_modules/.pnpm/preact-router@4.1.2_preact@10.27.1/node_modules/preact-router/dist/preact-router.mjs
var preact_router_a={};function preact_router_c(n,t){for(var r in t)n[r]=t[r];return n}function preact_router_s(n,t,r){var i,o=/(?:\?([^#]*))?(#.*)?$/,e=n.match(o),u={};if(e&&e[1])for(var f=e[1].split("&"),c=0;c<f.length;c++){var s=f[c].split("=");u[decodeURIComponent(s[0])]=decodeURIComponent(s.slice(1).join("="))}n=preact_router_d(n.replace(o,"")),t=preact_router_d(t||"");for(var h=Math.max(n.length,t.length),v=0;v<h;v++)if(t[v]&&":"===t[v].charAt(0)){var l=t[v].replace(/(^:|[+*?]+$)/g,""),p=(t[v].match(/[+*?]+$/)||preact_router_a)[0]||"",m=~p.indexOf("+"),y=~p.indexOf("*"),U=n[v]||"";if(!U&&!y&&(p.indexOf("?")<0||m)){i=!1;break}if(u[l]=decodeURIComponent(U),m||y){u[l]=n.slice(v).map(decodeURIComponent).join("/");break}}else if(t[v]!==n[v]){i=!1;break}return(!0===r.default||!1!==i)&&u}function preact_router_h(n,t){return n.rank<t.rank?1:n.rank>t.rank?-1:n.index-t.index}function preact_router_v(n,t){return n.index=t,n.rank=function(n){return n.props.default?0:preact_router_d(n.props.path).map(preact_router_l).join("")}(n),n.props}function preact_router_d(n){return n.replace(/(^\/+|\/+$)/g,"").split("/")}function preact_router_l(n){return":"==n.charAt(0)?1+"*+?".indexOf(n.charAt(n.length-1))||4:5}var preact_router_p={},preact_router_m=[],preact_router_y=[],U=null,preact_router_g={url:R()},preact_router_k=Q(preact_router_g);function preact_router_C(){var n=e(preact_router_k);if(n===preact_router_g){var t=u()[1];f(function(){return preact_router_y.push(t),function(){return preact_router_y.splice(preact_router_y.indexOf(t),1)}},[])}return[n,preact_router_$]}function R(){var n;return""+((n=U&&U.location?U.location:U&&U.getCurrentLocation?U.getCurrentLocation():"undefined"!=typeof location?location:preact_router_p).pathname||"")+(n.search||"")}function preact_router_$(n,t){return void 0===t&&(t=!1),"string"!=typeof n&&n.url&&(t=n.replace,n=n.url),function(n){for(var t=preact_router_m.length;t--;)if(preact_router_m[t].canRoute(n))return!0;return!1}(n)&&function(n,t){void 0===t&&(t="push"),U&&U[t]?U[t](n):"undefined"!=typeof history&&history[t+"State"]&&history[t+"State"](null,null,n)}(n,t?"replace":"push"),preact_router_I(n)}function preact_router_I(n){for(var t=!1,r=0;r<preact_router_m.length;r++)preact_router_m[r].routeTo(n)&&(t=!0);return t}function preact_router_M(n){if(n&&n.getAttribute){var t=n.getAttribute("href"),r=n.getAttribute("target");if(t&&t.match(/^\//g)&&(!r||r.match(/^_?self$/i)))return preact_router_$(t)}}function preact_router_b(n){return n.stopImmediatePropagation&&n.stopImmediatePropagation(),n.stopPropagation&&n.stopPropagation(),n.preventDefault(),!1}function W(n){if(!(n.ctrlKey||n.metaKey||n.altKey||n.shiftKey||n.button)){var t=n.target;do{if("a"===t.localName&&t.getAttribute("href")){if(t.hasAttribute("data-native")||t.hasAttribute("native"))return;if(preact_router_M(t))return preact_router_b(n)}}while(t=t.parentNode)}}var preact_router_w=!1;function preact_router_D(n){n.history&&(U=n.history),this.state={url:n.url||R()}}preact_router_c(preact_router_D.prototype=new x,{shouldComponentUpdate:function(n){return!0!==n.static||n.url!==this.props.url||n.onChange!==this.props.onChange},canRoute:function(n){var t=H(this.props.children);return void 0!==this.g(t,n)},routeTo:function(n){this.setState({url:n});var t=this.canRoute(n);return this.p||this.forceUpdate(),t},componentWillMount:function(){this.p=!0},componentDidMount:function(){var n=this;preact_router_w||(preact_router_w=!0,U||addEventListener("popstate",function(){preact_router_I(R())}),addEventListener("click",W)),preact_router_m.push(this),U&&(this.u=U.listen(function(t){var r=t.location||t;n.routeTo(""+(r.pathname||"")+(r.search||""))})),this.p=!1},componentWillUnmount:function(){"function"==typeof this.u&&this.u(),preact_router_m.splice(preact_router_m.indexOf(this),1)},componentWillUpdate:function(){this.p=!0},componentDidUpdate:function(){this.p=!1},g:function(n,t){n=n.filter(preact_router_v).sort(preact_router_h);for(var r=0;r<n.length;r++){var i=n[r],o=preact_router_s(t,i.props.path,i.props);if(o)return[i,o]}},render:function(n,t){var e,u,f=n.onChange,a=t.url,s=this.c,h=this.g(H(n.children),a);if(h&&(u=K(h[0],preact_router_c(preact_router_c({url:a,matches:e=h[1]},e),{key:void 0,ref:void 0}))),a!==(s&&s.url)){preact_router_c(preact_router_g,s=this.c={url:a,previous:s&&s.url,current:u,path:u?u.props.path:null,matches:e}),s.router=this,s.active=u?[u]:[];for(var v=preact_router_y.length;v--;)preact_router_y[v]({});"function"==typeof f&&f(s)}return _(preact_router_k.Provider,{value:s},u)}});var preact_router_E=function(n){return o("a",preact_router_c({onClick:W},n))},preact_router_L=function(n){return o(n.component,n)};
//# sourceMappingURL=preact-router.module.js.map

;// ./src/lib/hashHistory.ts
function getLocation() {
    var hash = window.location.hash.replace(/^#/, "") || "/";
    var _a = hash.split("?"), pathname = _a[0], _b = _a[1], search = _b === void 0 ? "" : _b;
    return {
        pathname: pathname || "/",
        search: search ? "?" + search : "",
        hash: window.location.hash,
    };
}
var hashHistory = {
    getCurrentLocation: getLocation,
    push: function (path) {
        window.location.hash = path;
    },
    replace: function (path) {
        var href = window.location.href.replace(/(#[^!]*)?$/, "") + "#" + path;
        window.location.replace(href);
    },
    listen: function (fn) {
        var handler = function () { return fn(getLocation()); };
        window.addEventListener("hashchange", handler);
        return function () { return window.removeEventListener("hashchange", handler); };
    },
    get location() {
        return getLocation();
    },
};
/* harmony default export */ const lib_hashHistory = (hashHistory);

;// ./src/state/AppStore.tsx
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};



var sampleTx = [
    {
        id: "t1",
        amount: 12.5,
        fee: 0.05,
        currency: "EUR",
        ts: new Date(Date.now() - 1000 * 60 * 60 * 20),
    },
    {
        id: "t2",
        amount: 5.9,
        fee: 0.03,
        currency: "EUR",
        ts: new Date(Date.now() - 1000 * 60 * 60 * 12),
    },
    {
        id: "t3",
        amount: 31,
        fee: 0.1,
        currency: "EUR",
        ts: new Date(Date.now() - 1000 * 60 * 60 * 8),
    },
    {
        id: "t4",
        amount: 7.25,
        fee: 0.02,
        currency: "EUR",
        ts: new Date(Date.now() - 1000 * 60 * 60 * 3),
    },
    {
        id: "t5",
        amount: 19.99,
        fee: 0.07,
        currency: "EUR",
        ts: new Date(Date.now() - 1000 * 60 * 30),
    },
];
var initialState = {
    paymentPointer: "",
    currency: "EUR",
    amount: "0",
    tx: sampleTx,
    error: null,
    _hasHydrated: false,
};
function reducer(state, action) {
    switch (action.type) {
        case "setPaymentPointer":
            return __assign(__assign({}, state), { paymentPointer: action.value });
        case "setCurrency":
            return __assign(__assign({}, state), { currency: action.value });
        case "setAmount":
            return __assign(__assign({}, state), { amount: action.value });
        case "setTx":
            return __assign(__assign({}, state), { tx: action.value });
        case "setError":
            return __assign(__assign({}, state), { error: action.value });
        case "setHasHydrated":
            return __assign(__assign({}, state), { _hasHydrated: action.value });
        default:
            return state;
    }
}
var StoreContext = Q(undefined);
function AppStoreProvider(_a) {
    var children = _a.children;
    var _b = hooks_module_h(reducer, initialState), state = _b[0], dispatch = _b[1];
    // Hydrate from localStorage
    hooks_module_y(function () {
        try {
            var raw = localStorage.getItem("ilfpos");
            if (raw) {
                var parsed = JSON.parse(raw);
                dispatch({
                    type: "setPaymentPointer",
                    value: parsed.paymentPointer || "https://ilp.dev/009" || 0,
                });
                dispatch({ type: "setCurrency", value: parsed.currency || "EUR" });
                dispatch({ type: "setAmount", value: parsed.amount || "0" });
                dispatch({
                    type: "setTx",
                    value: Array.isArray(parsed.tx)
                        ? parsed.tx.map(function (t) { return (__assign(__assign({}, t), { ts: new Date(t.ts) })); })
                        : sampleTx,
                });
                dispatch({ type: "setError", value: parsed.error || null });
            }
        }
        catch (e) {
            // ignore
        }
        dispatch({ type: "setHasHydrated", value: true });
    }, []);
    // Persist to localStorage
    hooks_module_y(function () {
        if (state._hasHydrated) {
            // Serialize to a plain object for localStorage
            var toSave = __assign(__assign({}, state), { tx: state.tx.map(function (t) { return (__assign(__assign({}, t), { ts: t.ts instanceof Date ? t.ts.toISOString() : t.ts })); }) });
            localStorage.setItem("ilfpos", JSON.stringify(toSave));
        }
    }, [state]);
    return (jsxRuntime_module_u(StoreContext.Provider, { value: [state, dispatch], children: children }));
}
// Custom hook to use the store
function useAppStore() {
    var ctx = hooks_module_x(StoreContext);
    if (!ctx)
        throw new Error("useAppStore must be used within AppStoreProvider");
    var state = ctx[0], dispatch = ctx[1];
    // Provide state and setter functions for compatibility
    return __assign(__assign({}, state), { setPaymentPointer: function (v) {
            return dispatch({ type: "setPaymentPointer", value: v });
        }, setCurrency: function (v) { return dispatch({ type: "setCurrency", value: v }); }, setAmount: function (v) { return dispatch({ type: "setAmount", value: v }); }, setTx: function (tx) { return dispatch({ type: "setTx", value: tx }); }, setError: function (v) { return dispatch({ type: "setError", value: v }); }, setHasHydrated: function (v) {
            return dispatch({ type: "setHasHydrated", value: v });
        } });
}
// Selector for totalBalance
function selectTotalBalance(state) {
    var tx = state.tx;
    if (!Array.isArray(tx))
        return 0;
    return tx.reduce(function (a, t) { return a + t.amount - t.fee; }, 0);
}
// Debug: Read and decode persisted state from localStorage
function debugReadPersistedState() {
    try {
        var raw = localStorage.getItem("ilfpos");
        if (!raw) {
            console.log("No ilfpos found in localStorage");
            return null;
        }
        var decoded = JSON.parse(raw);
        console.log("Decoded ilfpos:", decoded);
        return decoded;
    }
    catch (e) {
        console.error("Error decoding ilfpos:", e);
        return null;
    }
}

;// ./src/components/Header.tsx



//import { shortenPaymentPointer } from "@lib/paymentPointer";
function Header() {
    var paymentPointer = useAppStore().paymentPointer;
    return (jsxRuntime_module_u("header", { className: "flex items-center justify-between px-4 py-3 border-b border-white/10", children: [jsxRuntime_module_u("div", { className: "flex items-center gap-2", children: [jsxRuntime_module_u("a", { href: "/menu", className: "h-8 w-8 rounded-xl bg-emerald-400/20 grid place-items-center", onClick: function (e) {
                            e.preventDefault();
                            preact_router_$("/menu");
                        }, children: jsxRuntime_module_u("span", { className: "text-emerald-300 font-bold", children: "IL" }) }), jsxRuntime_module_u("h1", { className: "text-lg font-semibold", children: "Interledger POS" })] }), jsxRuntime_module_u("div", { className: "text-xs opacity-80", children: paymentPointer ? (jsxRuntime_module_u(k, { children: jsxRuntime_module_u("span", { className: "truncate max-w-[220px] align-middle", children: paymentPointer.split("/").pop() }) })) : (jsxRuntime_module_u("span", { className: "italic", children: "No payment pointer" })) })] }));
}

;// ./src/components/Layout.tsx


function Layout(_a) {
    var children = _a.children;
    return (jsxRuntime_module_u("div", { className: "min-h-screen w-full bg-gradient-to-b from-slate-900 to-slate-800 text-white", children: [jsxRuntime_module_u(Header, {}), jsxRuntime_module_u("main", { className: "mx-auto max-w-md p-4", children: children })] }));
}

;// ./src/pages/Splash.tsx



function Splash(_props) {
    var nav = preact_router_$;
    hooks_module_y(function () {
        var id = setTimeout(function () { return nav("/setup"); }, 900);
        return function () { return clearTimeout(id); };
    }, [nav]);
    return (jsxRuntime_module_u("div", { className: "h-[70vh] grid place-items-center", children: jsxRuntime_module_u("div", { className: "text-center", children: [jsxRuntime_module_u("div", { className: "text-4xl font-extrabold tracking-tight", children: "Interledger POS" }), jsxRuntime_module_u("div", { className: "mt-2 text-white/70", children: "Fast \u00B7 Open \u00B7 Seamless" }), jsxRuntime_module_u("div", { className: "mt-8 animate-pulse text-sm text-white/60", children: "Loading\u2026" })] }) }));
}

;// ./src/lib/paymentPointer.ts
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
function handlePaymentPointerEnter(pp_1, _a) {
    return __awaiter(this, arguments, void 0, function (pp, _b) {
        var data, error_1;
        var setError = _b.setError, setPaymentPointer = _b.setPaymentPointer, setPaymentPointerInput = _b.setPaymentPointerInput, setCurrency = _b.setCurrency, nav = _b.nav;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    setPaymentPointerInput(pp);
                    try {
                        validatePaymentPointer(pp);
                        setError("");
                    }
                    catch (error) {
                        setError(error.message);
                        return [2 /*return*/, false];
                    }
                    _c.label = 1;
                case 1:
                    _c.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, get(pp)];
                case 2:
                    data = _c.sent();
                    setPaymentPointer(pp);
                    setCurrency(data.assetCode);
                    nav("/menu");
                    return [2 /*return*/, true];
                case 3:
                    error_1 = _c.sent();
                    console.error("Error fetching payment pointer data:", error_1);
                    setError("Invalid payment pointer");
                    return [2 /*return*/, false];
                case 4: return [2 /*return*/];
            }
        });
    });
}
var WalletValidationError = /** @class */ (function (_super) {
    __extends(WalletValidationError, _super);
    function WalletValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "WalletValidationError";
        return _this;
    }
    return WalletValidationError;
}(Error));

function normalize(paymentPointer) {
    if (!paymentPointer.startsWith("$")) {
        return paymentPointer;
    }
    var withoutDollar = paymentPointer.slice(1);
    return "https://".concat(withoutDollar);
}
function isWalletAddress(x) {
    if (!x || typeof x !== "object")
        return false;
    var o = x;
    return (typeof o.id === "string" &&
        typeof o.authServer === "string" &&
        o.authServer.startsWith("https://") &&
        typeof o.resourceServer === "string" &&
        o.resourceServer.startsWith("https://"));
}
function get(paymentPointer) {
    return __awaiter(this, void 0, void 0, function () {
        var endpoint, res, json;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    endpoint = normalize(paymentPointer);
                    console.log("ENDPOINT: ", endpoint);
                    return [4 /*yield*/, fetch(endpoint, {
                            method: "GET",
                            headers: { Accept: "application/json" },
                        })];
                case 1:
                    res = _a.sent();
                    if (!res.ok) {
                        throw new Error("Failed to access the wallet address url");
                    }
                    return [4 /*yield*/, res.json()];
                case 2:
                    json = _a.sent();
                    if (!isWalletAddress(json))
                        throw new Error("Invalid wallet response for " + paymentPointer);
                    return [2 /*return*/, json];
            }
        });
    });
}
function validatePaymentPointer(paymentPointer) {
    if (!paymentPointer || typeof paymentPointer !== "string") {
        throw new WalletValidationError("must be a string");
    }
    var urlString = paymentPointer.trim();
    if (urlString.startsWith("$")) {
        urlString = urlString.replace(/^\$/, "https://");
    }
    if (!urlString.startsWith("https://")) {
        throw new WalletValidationError("must start with https:// or $");
    }
    if (urlString.includes(" ")) {
        throw new WalletValidationError("must not contain spaces");
    }
    var allowedChars = /^[a-zA-Z0-9\-._~:?#/]+$/;
    if (!allowedChars.test(urlString)) {
        throw new WalletValidationError("contains invalid characters");
    }
    var url;
    try {
        url = new URL(urlString);
    }
    catch (err) {
        throw new WalletValidationError("is not a valid URL");
    }
    if (url.protocol !== "https:") {
        throw new WalletValidationError("must use HTTPS protocol");
    }
    if (!url.hostname) {
        throw new WalletValidationError("must include a domain name");
    }
    if (url.search || url.hash) {
        throw new WalletValidationError("must not contain query string or fragment");
    }
    if (url.pathname && !url.pathname.startsWith("/")) {
        throw new WalletValidationError("path must start with a slash");
    }
    var hostnameRegex = /^(?=.{1,253}$)(?!.*\.\.)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)(\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    if (!hostnameRegex.test(url.hostname)) {
        throw new WalletValidationError("Domain name is not valid");
    }
    return true;
}

;// ./src/pages/Setup.tsx
var Setup_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var Setup_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





function Setup(_props) {
    var _this = this;
    var nav = preact_router_$;
    var _a = useAppStore(), paymentPointer = _a.paymentPointer, setPaymentPointer = _a.setPaymentPointer, setCurrency = _a.setCurrency, error = _a.error, setError = _a.setError, _hasHydrated = _a._hasHydrated;
    if (!_hasHydrated) {
        return null; // or a loading spinner
    }
    var initialPointer = hooks_module_A(paymentPointer);
    var _b = hooks_module_d("https://ilp.dev/009"), paymentPointerInput = _b[0], setPaymentPointerInput = _b[1];
    hooks_module_y(function () {
        setError("");
        console.log("Setup mounted with pp: ", (initialPointer.current, initialPointer.current.trim().length));
        if (initialPointer.current && initialPointer.current.trim().length > 0) {
            nav("/menu");
        }
    }, []);
    hooks_module_y(function () {
        var handleKeyDown = function (e) {
            if (paymentPointer !== "" &&
                paymentPointerInput !== "" &&
                (e.key === "ArrowLeft" || e.key === "Backspace")) {
                console.log("Navigating to menu", paymentPointerInput);
                nav("/menu");
                e.preventDefault();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return function () { return window.removeEventListener("keydown", handleKeyDown); };
    }, [nav, paymentPointerInput, paymentPointer]);
    var inputRef = hooks_module_A(null);
    hooks_module_y(function () {
        var _a;
        (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    }, []);
    return (jsxRuntime_module_u("section", { className: "space-y-6", children: [jsxRuntime_module_u("h2", { className: "text-xl font-semibold", children: "Merchant setup" }), jsxRuntime_module_u("label", { className: "block", children: [jsxRuntime_module_u("span", { className: "text-sm text-white/80", "data-l10n-id": "payment-pointer" }), jsxRuntime_module_u("input", { ref: inputRef, className: "mt-2 w-full rounded-xl bg-white/10 px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-400 placeholder-white/40", placeholder: "e.g., $example.com/alice", value: paymentPointerInput, onKeyDown: function (e) { return Setup_awaiter(_this, void 0, void 0, function () {
                            var value;
                            return Setup_generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        if (!(e.key === "Enter")) return [3 /*break*/, 2];
                                        e.preventDefault();
                                        value = e.target.value;
                                        return [4 /*yield*/, handlePaymentPointerEnter(value, {
                                                setError: setError,
                                                setPaymentPointer: setPaymentPointer,
                                                setPaymentPointerInput: setPaymentPointerInput,
                                                setCurrency: setCurrency,
                                                nav: nav,
                                            })];
                                    case 1:
                                        _a.sent();
                                        _a.label = 2;
                                    case 2: return [2 /*return*/];
                                }
                            });
                        }); } }), error && jsxRuntime_module_u("p", { className: "mt-2 text-sm text-red-500", children: error })] })] }));
}

;// ./src/pages/Menu.tsx




function Menu(_props) {
    var nav = preact_router_$;
    var paymentPointer = useAppStore().paymentPointer;
    var items = [
        { key: "sell", label: "Sell", path: "/sell", hint: "Accept a payment" },
        {
            key: "balance",
            label: "Balance",
            path: "/balance",
            hint: "View recent transactions",
        },
        {
            key: "eod",
            label: "End of day report",
            path: "/eod",
            hint: "Daily totals & email",
        },
        {
            key: "settings",
            label: "Settings",
            path: "/settings",
            hint: "Configure device",
        },
    ];
    var _a = hooks_module_d(0), focused = _a[0], setFocused = _a[1]; // 0 = Sell
    var btnRefs = hooks_module_A([]);
    hooks_module_y(function () {
        if (paymentPointer.trim().length == 0) {
            nav("/setup");
        }
    }, []);
    hooks_module_y(function () {
        var _a;
        (_a = btnRefs.current[focused]) === null || _a === void 0 ? void 0 : _a.focus();
    }, [focused]);
    hooks_module_y(function () {
        var handleKeyDown = function (e) {
            if (e.key === "ArrowDown" || e.key === "ArrowRight") {
                setFocused(function (f) { return (f + 1) % items.length; });
                e.preventDefault();
            }
            else if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
                setFocused(function (f) { return (f - 1 + items.length) % items.length; });
                e.preventDefault();
            }
            else if (e.key === "Enter" || e.key === " ") {
                nav(items[focused].path);
                e.preventDefault();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return function () { return window.removeEventListener("keydown", handleKeyDown); };
    }, [focused, nav]);
    return (jsxRuntime_module_u("section", { className: "flex flex-col gap-2 mt-2 w-full max-w-[270px] mx-auto px-1", style: { minWidth: 0 }, children: items.map(function (it, i) { return (jsxRuntime_module_u("button", { ref: function (el) {
                btnRefs.current[i] = el;
            }, tabIndex: i === focused ? 0 : -1, onClick: function () { return nav(it.path); }, className: "rounded-kai px-2 py-3 text-left shadow-inner transition-colors outline-none\n            ".concat(i === focused ? "bg-kaiAccent text-kaiBg" : "bg-white/10 text-kaiText", "\n            text-base font-semibold focus:ring-2 focus:ring-kaiAccent"), style: { minWidth: 0 }, children: jsxRuntime_module_u("div", { className: "flex flex-col", children: [jsxRuntime_module_u("span", { children: it.label }), jsxRuntime_module_u("span", { className: "text-xs text-kaiMuted", children: it.hint })] }) }, it.key)); }) }));
}

;// ./src/lib/currency.ts
function currencySymbol(c) {
    var m = {
        EUR: "€",
        USD: "$",
        GBP: "£",
    };
    return m[c] || c;
}
function formatCurrency(value, currency) {
    try {
        return new Intl.NumberFormat(undefined, {
            style: "currency",
            currency: currency,
        }).format(value || 0);
    }
    catch (_a) {
        var s = currencySymbol(currency);
        return "".concat(s).concat((value || 0).toFixed(2));
    }
}

;// ./src/pages/Sell.tsx





function Sell(_props) {
    var nav = preact_router_$;
    var _a = useAppStore(), paymentPointer = _a.paymentPointer, currency = _a.currency, amount = _a.amount, setAmount = _a.setAmount;
    var onKey = function (key) {
        var newAmount = amount;
        if (key === "C") {
            newAmount = "0";
        }
        else if (key === "⌫") {
            newAmount = amount.length <= 1 ? "0" : amount.slice(0, -1);
        }
        else if (key === ".") {
            newAmount = amount.includes(".") ? amount : amount + ".";
        }
        else if (/^\d$/.test(key)) {
            if (amount === "0")
                newAmount = key;
            else if (amount.length < 9)
                newAmount = amount + key;
            // else leave as is
        }
        setAmount(newAmount);
    };
    hooks_module_y(function () {
        var handleKeyDown = function (e) {
            if (e.repeat)
                return;
            if (e.key >= "0" && e.key <= "9") {
                onKey(e.key);
                e.preventDefault();
            }
            else if (e.key === "." || e.key === ",") {
                onKey(".");
                e.preventDefault();
            }
            else if (e.key === "Backspace") {
                // Backspace: go to menu if amount is 0, else delete
                if (parseFloat(amount || "0") === 0) {
                    nav("/menu");
                }
                else {
                    onKey("⌫");
                }
                e.preventDefault();
            }
            else if (e.key === "ArrowLeft") {
                nav("/menu");
                e.preventDefault();
            }
            else if (e.key.toLowerCase() === "c") {
                onKey("C");
                e.preventDefault();
            }
            else if (e.key === "Enter") {
                if (parseFloat(amount || "0") > 0) {
                    nav("/wait-card");
                }
                e.preventDefault();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return function () { return window.removeEventListener("keydown", handleKeyDown); };
    }, [amount, nav]);
    hooks_module_y(function () {
        if (paymentPointer.length == 0) {
            nav("/setup");
        }
    }, []);
    return (jsxRuntime_module_u("section", { className: "space-y-4", children: [jsxRuntime_module_u("div", { className: "flex items-center justify-between", children: [jsxRuntime_module_u("button", { onClick: function () { return nav("/menu"); }, className: "text-sm text-white/70 hover:text-white", children: "\u2190 Back" }), jsxRuntime_module_u("div", { className: "text-sm text-white/70", children: "Sell" }), jsxRuntime_module_u("div", { className: "w-10" })] }), jsxRuntime_module_u("div", { className: "rounded-xl bg-white/10 px-4 py-6 text-center", children: jsxRuntime_module_u("div", { className: "text-4xl font-bold tabular-nums", children: formatCurrency(parseFloat(amount || "0"), currency) }) })] }));
}

;// ./src/lib/generateAC.ts
// generateAC.ts - APDU command generation utilities
var APDU_COMMANDS = {
    SELECT_PPSE: "00A404000AA00000015103010C0601",
    GENERATE_AC: "80AEC100", // Will be completed with raw data
};
function hexStringToUint8Array(hexString) {
    var bytes = [];
    for (var i = 0; i < hexString.length; i += 2) {
        bytes.push(parseInt(hexString.substr(i, 2), 16));
    }
    return new Uint8Array(bytes);
}
function uint8ArrayToHexString(uint8Array) {
    return Array.from(uint8Array)
        .map(function (byte) {
        var hex = byte.toString(16);
        return hex.length === 1 ? "0" + hex : hex;
    })
        .join(" ");
}
// (12 digits)
function createBCDAmount(amount) {
    var amountStr = Math.floor(amount * 100)
        .toString()
        .padStart(12, "0");
    var bcd = new Uint8Array(6);
    for (var i = 0; i < 6; i++) {
        var pair = amountStr.substr(i * 2, 2);
        bcd[i] = parseInt(pair, 16);
    }
    return bcd;
}
function createDate(date) {
    var year = date.getFullYear() % 100;
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return new Uint8Array([year, month, day]);
}
function currencyCodeToBytes(_currencyCode) {
    // Hardcoded to EUR for now
    return new Uint8Array([0x09, 0x78]);
}
function numberTo4Bytes(value) {
    var bytes = new Uint8Array(4);
    bytes[0] = (value >> 24) & 0xff;
    bytes[1] = (value >> 16) & 0xff;
    bytes[2] = (value >> 8) & 0xff;
    bytes[3] = value & 0xff;
    return bytes;
}
function dateStringToBytes(dateStr) {
    var year = parseInt(dateStr.substr(0, 2), 10);
    var month = parseInt(dateStr.substr(2, 2), 10);
    var day = parseInt(dateStr.substr(4, 2), 10);
    return new Uint8Array([year, month, day]);
}
function createTransactionData(amount) {
    if (amount === void 0) { amount = 10; }
    var now = new Date();
    var year = now.getFullYear() % 100;
    var month = now.getMonth() + 1;
    var day = now.getDate();
    // Generate random 4-byte unpredictable number
    var unpredictableNumber = Math.floor(Math.random() * 0x100000000); // 0 to 0xFFFFFFFF
    return {
        amount: amount,
        currencyCode: "EUR",
        transactionCurrencyExponent: 2,
        date: "".concat(year.toString().padStart(2, "0")).concat(month.toString().padStart(2, "0")).concat(day.toString().padStart(2, "0")),
        unpredictableNumber: unpredictableNumber,
        senderWalletAddress: "https://wallet.example/alice",
        receiverWalletAddress: "https://wallet.example/alice",
    };
}
function createGenerateACCommand(transactionData) {
    // Convert transaction data to raw bytes for CDOL
    var amountData = createBCDAmount(transactionData.amount / 100);
    var currencyData = currencyCodeToBytes(transactionData.currencyCode);
    var exponentData = new Uint8Array([
        transactionData.transactionCurrencyExponent,
    ]);
    var dateData = dateStringToBytes(transactionData.date);
    var unpredictableData = numberTo4Bytes(transactionData.unpredictableNumber);
    var createPaddedPaymentPointer = function (pointer) {
        var asciiData = new Uint8Array(64);
        var encoder = new TextEncoder();
        var encoded = encoder.encode(pointer);
        asciiData.set(encoded, 0);
        // Rest is already padded with zeros
        return asciiData;
    };
    var recipientData = createPaddedPaymentPointer(transactionData.receiverWalletAddress);
    var senderData = createPaddedPaymentPointer(transactionData.senderWalletAddress);
    console.log("=== RAW DATA STRUCTURE ===");
    console.log("Amount (6 bytes):", uint8ArrayToHexString(amountData));
    console.log("Currency (2 bytes):", uint8ArrayToHexString(currencyData));
    console.log("Exponent (1 byte):", uint8ArrayToHexString(exponentData));
    console.log("Date (3 bytes):", uint8ArrayToHexString(dateData));
    console.log("Unpredictable (4 bytes):", uint8ArrayToHexString(unpredictableData));
    console.log("Recipient (64 bytes):", uint8ArrayToHexString(recipientData));
    console.log("Sender (64 bytes):", uint8ArrayToHexString(senderData));
    // Combine all raw data fields in order (no TLV encoding)
    var rawDataFields = [
        amountData, // 6 bytes
        currencyData, // 2 bytes
        exponentData, // 1 byte
        dateData, // 3 bytes
        unpredictableData, // 4 bytes
        recipientData, // 64 bytes
        senderData, // 64 bytes
    ];
    var totalLength = rawDataFields.reduce(function (sum, field) { return sum + field.length; }, 0);
    console.log("Total raw data length:", totalLength, "bytes");
    // Concatenate all raw data
    var rawData = new Uint8Array(totalLength);
    var offset = 0;
    for (var _i = 0, rawDataFields_1 = rawDataFields; _i < rawDataFields_1.length; _i++) {
        var field = rawDataFields_1[_i];
        rawData.set(field, offset);
        offset += field.length;
    }
    var commandHeader = hexStringToUint8Array(APDU_COMMANDS.GENERATE_AC);
    var lc = new Uint8Array([rawData.length]); // Length of data
    var le = new Uint8Array([0x00]); // Expected response length
    var completeCommand = new Uint8Array(commandHeader.length + lc.length + rawData.length + le.length);
    var cmdOffset = 0;
    completeCommand.set(commandHeader, cmdOffset);
    cmdOffset += commandHeader.length;
    completeCommand.set(lc, cmdOffset);
    cmdOffset += lc.length;
    completeCommand.set(rawData, cmdOffset);
    cmdOffset += rawData.length;
    completeCommand.set(le, cmdOffset);
    return completeCommand;
}

;// ./src/lib/paymentService.ts
// paymentService.ts - Payment service utilities
function createPaymentServiceData(transactionData) {
    return {
        applicationTransactionCounter: transactionData.unpredictableNumber
            .toString(16)
            .padStart(8, "0"),
        amount: transactionData.amount, // Already in cents
        currencyCode: transactionData.currencyCode,
        transactionCurrencyExponent: transactionData.transactionCurrencyExponent,
        date: transactionData.date,
        unpredictableNumber: transactionData.unpredictableNumber
            .toString(16)
            .padStart(8, "0"),
        senderWalletAddress: transactionData.senderWalletAddress,
        receiverWalletAddress: transactionData.receiverWalletAddress,
    };
}

;// ./src/pages/WaitCard.tsx
var WaitCard_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var WaitCard_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

// WaitCard.tsx




function WaitCard(_a) {
    var _this = this;
    var path = _a.path, decrement = _a.decrement, playRingtone = _a.playRingtone, onTagLost = _a.onTagLost, onCancel = _a.onCancel, _b = _a.autoFocus, autoFocus = _b === void 0 ? true : _b, _c = _a.className, className = _c === void 0 ? "" : _c;
    var panelRef = hooks_module_A(null);
    var sendAPDUCommands = hooks_module_q(function (tag) { return WaitCard_awaiter(_this, void 0, void 0, function () {
        var tech, selectPPSE, selectResponse, transactionData, generateAC, generateResponse, paymentData, error_1;
        return WaitCard_generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    console.log("Starting APDU communication with tag...");
                    if (tag.techList.indexOf("ISO-DEP") === -1) {
                        console.error("Tag does not support ISO-DEP protocol");
                        return [2 /*return*/];
                    }
                    tech = tag.selectTech("ISO-DEP");
                    if (!tech) {
                        console.error("Failed to select ISO-DEP technology");
                        return [2 /*return*/];
                    }
                    console.log("Selected ISO-DEP technology, tech object:", tech);
                    // Send SELECT PPSE command
                    console.log("=== SELECT PPSE COMMAND ===");
                    console.log("Command hex string:", APDU_COMMANDS.SELECT_PPSE);
                    selectPPSE = hexStringToUint8Array(APDU_COMMANDS.SELECT_PPSE);
                    console.log("Command bytes (Uint8Array):", selectPPSE);
                    console.log("Command bytes (hex):", uint8ArrayToHexString(selectPPSE));
                    return [4 /*yield*/, tech.transceive(selectPPSE)];
                case 1:
                    selectResponse = _a.sent();
                    console.log("Response bytes (Uint8Array):", selectResponse);
                    console.log("Response bytes (hex):", uint8ArrayToHexString(selectResponse));
                    console.log("Response length:", selectResponse.length, "bytes");
                    // Create transaction data
                    console.log("=== TRANSACTION DATA ===");
                    transactionData = createTransactionData(10);
                    console.log("Transaction data:", JSON.stringify(transactionData, null, 2));
                    // Send GENERATE AC command with transaction data
                    console.log("=== GENERATE AC COMMAND ===");
                    generateAC = createGenerateACCommand(transactionData);
                    console.log("Command bytes (Uint8Array):", generateAC);
                    console.log("Command bytes (hex):", uint8ArrayToHexString(generateAC));
                    console.log("Command length:", generateAC.length, "bytes");
                    return [4 /*yield*/, tech.transceive(generateAC)];
                case 2:
                    generateResponse = _a.sent();
                    console.log("Response bytes (Uint8Array):", generateResponse);
                    console.log("Response bytes (hex):", uint8ArrayToHexString(generateResponse));
                    console.log("Response length:", generateResponse.length, "bytes");
                    paymentData = createPaymentServiceData(transactionData);
                    console.log("=== PAYMENT SERVICE JSON ===");
                    console.log("Transaction JSON for payment service:", JSON.stringify(paymentData, null, 2));
                    console.log("APDU communication completed successfully");
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _a.sent();
                    console.error("Error during APDU communication:", error_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); }, []);
    var handleTagFound = hooks_module_q(function (event) {
        var _a;
        console.log("event", event);
        var tag = event.tag;
        console.log("NfcDemo tag found:", tag);
        if (!tag)
            return;
        // UX feedback
        if ("vibrate" in navigator)
            (_a = navigator.vibrate) === null || _a === void 0 ? void 0 : _a.call(navigator, 100);
        playRingtone === null || playRingtone === void 0 ? void 0 : playRingtone();
        if (Array.isArray(tag.techList) &&
            tag.techList.indexOf("ISO-DEP") !== -1) {
            console.log("Tag supports ISO-DEP, starting APDU communication...");
            console.log("Available technologies:", tag.techList);
            console.log("Tag object methods:", Object.getOwnPropertyNames(tag));
            // prevent default so mozNfc doesn't immediately fire taglost
            if (typeof event.preventDefault === "function") {
                try {
                    event.preventDefault();
                }
                catch (_b) { }
            }
            // Send APDU commands
            sendAPDUCommands(tag);
        }
        else {
            console.log("Tag does not support required technologies:", tag.techList);
        }
    }, [decrement, playRingtone, sendAPDUCommands]);
    var handleTagLost = hooks_module_q(function (event) {
        console.log("NfcDemo tag lost:", event);
        onTagLost === null || onTagLost === void 0 ? void 0 : onTagLost(event);
    }, [onTagLost]);
    hooks_module_y(function () {
        if (autoFocus) {
            var panel_1 = panelRef.current;
            setTimeout(function () { return panel_1 === null || panel_1 === void 0 ? void 0 : panel_1.focus(); }, 0);
        }
        var nfc;
        try {
            nfc = window.navigator.mozNfc;
            if (!nfc)
                throw new Error("mozNfc not available");
            nfc.ontagfound = handleTagFound;
            nfc.ontaglost = handleTagLost;
            return function () {
                if (nfc) {
                    nfc.ontagfound = null;
                    nfc.ontaglost = null;
                }
            };
        }
        catch (err) {
            console.log("mozNfc not available or error:", err);
            console.log("run later from here a cancel process function if needed");
            // commenting out this for now.
            //onCancel?.(); // Uncomment if we want to auto-cancel when NFC is not available
        }
    }, [autoFocus, handleTagFound, handleTagLost, onCancel]);
    hooks_module_y(function () {
        var handleKeyDown = function (e) {
            if (e.key === "Backspace" ||
                e.key === "ArrowLeft" ||
                e.key === "SoftRight" || //lets see if this works.
                e.key === "EndCall" //lets see if this works.
            ) {
                preact_router_$("/sell");
                e.preventDefault();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return function () { return window.removeEventListener("keydown", handleKeyDown); };
    }, []);
    return (jsxRuntime_module_u("div", { ref: panelRef, tabIndex: -1, className: "rounded-2xl p-6 bg-white/5 ring-1 ring-white/10 ".concat(className), children: [jsxRuntime_module_u("h2", { className: "text-lg font-semibold", children: "Hold card near the reader" }), jsxRuntime_module_u("p", { className: "mt-2 text-white/70", children: "Waiting for an NFC card\u2026 keep it in the field until confirmed." })] }));
}

;// ./src/pages/Balance.tsx





function Balance(_props) {
    var nav = preact_router_$;
    var _a = useAppStore(), currency = _a.currency, tx = _a.tx;
    var totalBalance = selectTotalBalance({ tx: tx });
    hooks_module_y(function () {
        var handleKeyDown = function (e) {
            if (e.key === "ArrowLeft" || e.key === "Backspace") {
                nav("/menu");
                e.preventDefault();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return function () { return window.removeEventListener("keydown", handleKeyDown); };
    }, [nav]);
    return (jsxRuntime_module_u("section", { className: "space-y-5", children: [jsxRuntime_module_u("div", { className: "flex items-center justify-between", children: [jsxRuntime_module_u("button", { onClick: function () { return nav("/menu"); }, className: "text-sm text-white/70 hover:text-white", children: "\u2190 Back" }), jsxRuntime_module_u("div", { className: "text-sm text-white/70", children: "Balance" }), jsxRuntime_module_u("div", { className: "w-10" })] }), jsxRuntime_module_u("div", { className: "rounded-2xl bg-emerald-500/10 p-5", children: [jsxRuntime_module_u("div", { className: "text-sm text-white/70", children: "Total balance" }), jsxRuntime_module_u("div", { className: "text-3xl font-bold mt-1", children: formatCurrency(totalBalance, currency) })] }), jsxRuntime_module_u("div", { children: [jsxRuntime_module_u("h3", { className: "text-sm text-white/80 mb-2", children: "Recent transactions" }), jsxRuntime_module_u("ul", { className: "space-y-2", children: tx.slice(0, 5).map(function (t) {
                            var _a, _b;
                            return (jsxRuntime_module_u("li", { className: "flex items-center justify-between rounded-xl bg-white/5 px-4 py-3", children: [jsxRuntime_module_u("div", { children: [jsxRuntime_module_u("div", { className: "font-medium", children: formatCurrency(t.amount, t.currency) }), jsxRuntime_module_u("div", { className: "text-xs text-white/60", children: ["Fee ", formatCurrency(t.fee, t.currency), " \u2022", " ", ((_b = (_a = t.ts).toLocaleString) === null || _b === void 0 ? void 0 : _b.call(_a)) || String(t.ts)] })] }), jsxRuntime_module_u("div", { className: "text-white/70 text-xs", children: ["#", t.id.slice(0, 6)] })] }, t.id));
                        }) })] })] }));
}

;// ./src/services/reports.ts
function computeDailyReport(date, items) {
    var day = new Date(date);
    var year = day.getFullYear();
    var month = day.getMonth();
    var dateOfMonth = day.getDate();
    var filtered = items.filter(function (t) {
        var txDate = t.ts instanceof Date ? t.ts : new Date(t.ts);
        return (txDate.getFullYear() === year &&
            txDate.getMonth() === month &&
            txDate.getDate() === dateOfMonth);
    });
    var count = filtered.length;
    var sum = filtered.reduce(function (a, t) { return a + t.amount; }, 0);
    var fees = filtered.reduce(function (a, t) { return a + t.fee; }, 0);
    var first = filtered.length
        ? new Date(Math.min.apply(Math, filtered.map(function (t) {
            return t.ts instanceof Date ? t.ts.getTime() : new Date(t.ts).getTime();
        })))
        : undefined;
    var last = filtered.length
        ? new Date(Math.max.apply(Math, filtered.map(function (t) {
            return t.ts instanceof Date ? t.ts.getTime() : new Date(t.ts).getTime();
        })))
        : undefined;
    return { items: filtered, count: count, sum: sum, fees: fees, first: first, last: last };
}

;// ./src/pages/EndOfDay.tsx






function EndOfDay(_props) {
    var _a, _b;
    var nav = preact_router_$;
    var _c = useAppStore(), currency = _c.currency, tx = _c.tx;
    var _d = hooks_module_d(function () {
        return new Date().toISOString().slice(0, 10);
    }), reportDate = _d[0], setReportDate = _d[1];
    var report = hooks_module_T(function () { return computeDailyReport(reportDate, tx); }, [reportDate, tx]);
    var count = report.count, sum = report.sum, fees = report.fees, first = report.first, last = report.last, items = report.items;
    hooks_module_y(function () {
        var handleKeyDown = function (e) {
            if (e.key === "ArrowLeft" || e.key === "Backspace") {
                nav("/menu");
                e.preventDefault();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return function () { return window.removeEventListener("keydown", handleKeyDown); };
    }, [nav]);
    return (jsxRuntime_module_u("section", { className: "space-y-5", children: [jsxRuntime_module_u("div", { className: "flex items-center justify-between", children: [jsxRuntime_module_u("button", { onClick: function () { return nav("/menu"); }, className: "text-sm text-white/70 hover:text-white", children: "\u2190 Back" }), jsxRuntime_module_u("div", { className: "text-sm text-white/70", children: "End of day report" }), jsxRuntime_module_u("div", { className: "w-10" })] }), jsxRuntime_module_u("label", { className: "block", children: [jsxRuntime_module_u("span", { className: "text-sm text-white/80", children: "Report date" }), jsxRuntime_module_u("input", { type: "date", className: "mt-2 w-full rounded-xl bg-white/10 px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-400", value: reportDate, onChange: function (e) { return setReportDate(e.target.value); } })] }), jsxRuntime_module_u("div", { className: "grid grid-cols-2 gap-3", children: [jsxRuntime_module_u("div", { className: "rounded-2xl bg-white/10 p-4", children: [jsxRuntime_module_u("div", { className: "text-xs text-white/70", children: "Number of transactions" }), jsxRuntime_module_u("div", { className: "mt-1 text-lg font-semibold", children: String(count) })] }), jsxRuntime_module_u("div", { className: "rounded-2xl bg-white/10 p-4", children: [jsxRuntime_module_u("div", { className: "text-xs text-white/70", children: "Sum of all transactions" }), jsxRuntime_module_u("div", { className: "mt-1 text-lg font-semibold", children: formatCurrency(sum, currency) })] }), jsxRuntime_module_u("div", { className: "rounded-2xl bg-white/10 p-4", children: [jsxRuntime_module_u("div", { className: "text-xs text-white/70", children: "Sum of all fees" }), jsxRuntime_module_u("div", { className: "mt-1 text-lg font-semibold", children: formatCurrency(fees, currency) })] }), jsxRuntime_module_u("div", { className: "rounded-2xl bg-white/10 p-4", children: [jsxRuntime_module_u("div", { className: "text-xs text-white/70", children: "Net total (sum - fees)" }), jsxRuntime_module_u("div", { className: "mt-1 text-lg font-semibold", children: formatCurrency(sum - fees, currency) })] }), jsxRuntime_module_u("div", { className: "rounded-2xl bg-white/10 p-4", children: [jsxRuntime_module_u("div", { className: "text-xs text-white/70", children: "First transaction" }), jsxRuntime_module_u("div", { className: "mt-1 text-lg font-semibold", children: first ? (_a = first.toLocaleString) === null || _a === void 0 ? void 0 : _a.call(first) : "–" })] }), jsxRuntime_module_u("div", { className: "rounded-2xl bg-white/10 p-4", children: [jsxRuntime_module_u("div", { className: "text-xs text-white/70", children: "Last transaction" }), jsxRuntime_module_u("div", { className: "mt-1 text-lg font-semibold", children: last ? (_b = last.toLocaleString) === null || _b === void 0 ? void 0 : _b.call(last) : "–" })] })] }), jsxRuntime_module_u("div", { className: "rounded-2xl overflow-hidden border border-white/10", children: jsxRuntime_module_u("table", { className: "w-full text-sm", children: [jsxRuntime_module_u("thead", { className: "bg-white/10", children: jsxRuntime_module_u("tr", { children: [jsxRuntime_module_u("th", { className: "text-left px-3 py-2 font-medium", children: "Time" }), jsxRuntime_module_u("th", { className: "text-left px-3 py-2 font-medium", children: "Amount" }), jsxRuntime_module_u("th", { className: "text-left px-3 py-2 font-medium", children: "Fee" }), jsxRuntime_module_u("th", { className: "text-left px-3 py-2 font-medium", children: "ID" })] }) }), jsxRuntime_module_u("tbody", { children: [items.map(function (t) {
                                    var _a, _b;
                                    return (jsxRuntime_module_u("tr", { className: "odd:bg-white/5", children: [jsxRuntime_module_u("td", { className: "px-3 py-2", children: ((_b = (_a = t.ts).toLocaleString) === null || _b === void 0 ? void 0 : _b.call(_a)) || String(t.ts) }), jsxRuntime_module_u("td", { className: "px-3 py-2", children: formatCurrency(t.amount, currency) }), jsxRuntime_module_u("td", { className: "px-3 py-2", children: formatCurrency(t.fee, currency) }), jsxRuntime_module_u("td", { className: "px-3 py-2", children: t.id })] }, t.id));
                                }), !items.length && (jsxRuntime_module_u("tr", { children: jsxRuntime_module_u("td", { className: "px-3 py-6 text-center text-white/60", colSpan: 4, children: "No transactions for this date." }) }))] })] }) })] }));
}

;// ./src/pages/Settings.tsx
var Settings_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var Settings_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





function Settings(_props) {
    var _this = this;
    var nav = preact_router_$;
    var _a = useAppStore(), error = _a.error, setError = _a.setError, setCurrency = _a.setCurrency, paymentPointer = _a.paymentPointer, setPaymentPointer = _a.setPaymentPointer;
    var _b = hooks_module_d(paymentPointer), paymentPointerInput = _b[0], setPaymentPointerInput = _b[1];
    // handleEnterPress is now handled by handlePaymentPointerEnter helper
    hooks_module_y(function () {
        if (paymentPointer.length == 0) {
            nav("/setup");
        }
    }, []);
    hooks_module_y(function () {
        var handleKeyDown = function (e) {
            // lets remove this for now, check again after testing
            // const active = document.activeElement;
            // const isInput = active && (active.tagName === "INPUT" || active.tagName === "SELECT" || active.tagName === "TEXTAREA");
            // !isInput &&  || e.key === "Backspace"
            if ((e.key === "ArrowLeft" || e.key === "SoftRight" || e.key === "EndCall")) {
                nav("/menu");
                e.preventDefault();
            }
        };
        window.addEventListener("keydown", handleKeyDown);
        return function () { return window.removeEventListener("keydown", handleKeyDown); };
    }, [nav]);
    var inputRef = hooks_module_A(null);
    hooks_module_y(function () {
        var _a;
        (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    }, []);
    return (jsxRuntime_module_u("section", { className: "space-y-2", children: [jsxRuntime_module_u("div", { className: "flex items-center justify-between", children: [jsxRuntime_module_u("button", { onClick: function () { return nav("/menu"); }, className: "text-sm text-white/70 hover:text-white", children: "\u2190 Back" }), jsxRuntime_module_u("div", { className: "text-sm text-white/70", children: "Settings" }), jsxRuntime_module_u("div", { className: "w-10" })] }), jsxRuntime_module_u("label", { className: "block", children: [jsxRuntime_module_u("span", { className: "text-sm text-white/80", children: "Payment pointer" }), jsxRuntime_module_u("input", { ref: inputRef, className: "mt-2 w-full rounded-xl bg-white/10 px-2 py-2 outline-none focus:ring-2 focus:ring-emerald-400 placeholder-white/40", placeholder: "e.g., $example.com/alice", value: paymentPointerInput, onKeyDown: function (e) { return Settings_awaiter(_this, void 0, void 0, function () {
                            var value;
                            return Settings_generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        if (!(e.key === "Enter")) return [3 /*break*/, 2];
                                        e.preventDefault();
                                        value = e.target.value;
                                        return [4 /*yield*/, handlePaymentPointerEnter(value, {
                                                setError: setError,
                                                setPaymentPointer: setPaymentPointer,
                                                setPaymentPointerInput: setPaymentPointerInput,
                                                setCurrency: setCurrency,
                                                nav: nav,
                                            })];
                                    case 1:
                                        _a.sent();
                                        _a.label = 2;
                                    case 2: return [2 /*return*/];
                                }
                            });
                        }); } }), error && jsxRuntime_module_u("p", { className: "mt-2 text-sm text-red-500", children: error })] })] }));
}

;// ./src/routes/router.tsx












function AppRouter() {
    return (jsxRuntime_module_u(Layout, { children: jsxRuntime_module_u(preact_router_D, { history: lib_hashHistory, children: [jsxRuntime_module_u(Splash, { path: "/" }), jsxRuntime_module_u(Setup, { path: "/setup" }), jsxRuntime_module_u(Menu, { path: "/menu" }), jsxRuntime_module_u(Sell, { path: "/sell" }), jsxRuntime_module_u(WaitCard, { path: "/wait-card" }), jsxRuntime_module_u(Balance, { path: "/balance" }), jsxRuntime_module_u(EndOfDay, { path: "/eod" }), jsxRuntime_module_u(Settings, { path: "/settings" })] }) }));
}

;// ./src/main.tsx





G(jsxRuntime_module_u(AppStoreProvider, { children: jsxRuntime_module_u(AppRouter, {}) }), document.getElementById("root"));

/******/ })()
;